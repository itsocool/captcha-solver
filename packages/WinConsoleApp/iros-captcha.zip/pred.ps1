﻿#requires -Version 5.1
<#
.SYNOPSIS
captcha.exe 일괄 예측. 확장자를 제외한 파일명을 정답으로 비교합니다.
.EXAMPLE
.\pred.ps1
.NOTES
시간에는 이미지마다 CLI 시작 및 모델 로딩이 포함됩니다.
정답률의 분모는 실행 실패를 포함한 전체 이미지 수입니다.
#>
[CmdletBinding()]
param(
    [string]$ImageDirectory = '.\images\iros',
    [string]$CaptchaExe,
    [ValidatePattern('^[A-Za-z0-9_-]+$')]
    [string]$CaptchaId = 'iros',
    [switch]$Recurse
)

if (-not $CaptchaExe) { $CaptchaExe = Join-Path $PSScriptRoot 'captcha.exe' }

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
if (-not (Test-Path -LiteralPath $CaptchaExe -PathType Leaf)) {
    throw "CLI not found: $CaptchaExe"
}
if (-not (Test-Path -LiteralPath $ImageDirectory -PathType Container)) {
    throw "Image directory not found: $ImageDirectory"
}
$exePath = (Resolve-Path -LiteralPath $CaptchaExe).ProviderPath
$extensions = '.png', '.jpg', '.jpeg', '.bmp', '.gif', '.tga', '.psd', '.hdr', '.pnm', '.ppm', '.pgm'
$files = @(Get-ChildItem -LiteralPath $ImageDirectory -File -Recurse:$Recurse |
    Where-Object { $_.Extension.ToLowerInvariant() -in $extensions } |
    Sort-Object FullName)
if ($files.Count -eq 0) { throw "No supported images found: $ImageDirectory" }

$results = [System.Collections.Generic.List[object]]::new()
$totalTimer = [System.Diagnostics.Stopwatch]::StartNew()
Write-Host ("Model: {0} | Images: {1} | Expected label: filename without extension" -f $CaptchaId, $files.Count)
foreach ($file in $files) {
    $timer = [System.Diagnostics.Stopwatch]::StartNew()
    $prediction = ''
    $errorText = ''
    $exitCode = -1
    $process = [System.Diagnostics.Process]::new()
    try {
        $process.StartInfo.FileName = $exePath
        $process.StartInfo.Arguments = '-c="{0}" -i="{1}"' -f $CaptchaId, $file.FullName
        $process.StartInfo.UseShellExecute = $false
        $process.StartInfo.CreateNoWindow = $true
        $process.StartInfo.RedirectStandardOutput = $true
        $process.StartInfo.RedirectStandardError = $true
        $process.StartInfo.StandardOutputEncoding = [System.Text.Encoding]::UTF8
        $process.StartInfo.StandardErrorEncoding = [System.Text.Encoding]::UTF8
        [void]$process.Start()
        $stdout = $process.StandardOutput.ReadToEndAsync()
        $stderr = $process.StandardError.ReadToEndAsync()
        $process.WaitForExit()
        $prediction = $stdout.GetAwaiter().GetResult().Trim()
        $errorText = $stderr.GetAwaiter().GetResult().Trim()
        $exitCode = $process.ExitCode
    }
    catch { $errorText = $_.Exception.Message }
    finally {
        $timer.Stop()
        $process.Dispose()
    }
    $status = if ($exitCode -ne 0) { 'ERROR' }
        elseif ($prediction -ceq $file.BaseName) { 'OK' }
        else { 'WRONG' }
    $results.Add([pscustomobject]@{
        File = $file.FullName
        Expected = $file.BaseName
        Prediction = $prediction
        Status = $status
        ElapsedMs = $timer.Elapsed.TotalMilliseconds
        ExitCode = $exitCode
        Error = $errorText
    })
    Write-Host ('[{0}/{1}] {2} expected={3} predicted={4} {5:N1} ms' -f
        $results.Count, $files.Count, $status, $file.BaseName, $prediction, $timer.Elapsed.TotalMilliseconds)
    if ($errorText) { Write-Host "  stderr: $errorText" -ForegroundColor Yellow }
}
$totalTimer.Stop()
$correct = @($results | Where-Object Status -eq 'OK').Count
$wrong = @($results | Where-Object Status -eq 'WRONG').Count
$failed = @($results | Where-Object Status -eq 'ERROR').Count
$timing = $results | Measure-Object ElapsedMs -Average -Minimum -Maximum
Write-Host "`n--- Summary ---"
[pscustomobject]@{
    Total = $files.Count
    Correct = $correct
    Wrong = $wrong
    Errors = $failed
    'Accuracy (%) [correct/total]' = [math]::Round(100.0 * $correct / $files.Count, 2)
    'Total time (s)' = [math]::Round($totalTimer.Elapsed.TotalSeconds, 3)
    'Images/s' = [math]::Round($files.Count / $totalTimer.Elapsed.TotalSeconds, 2)
    'CLI time average (ms)' = [math]::Round($timing.Average, 2)
    'CLI time min (ms)' = [math]::Round($timing.Minimum, 2)
    'CLI time max (ms)' = [math]::Round($timing.Maximum, 2)
} | Format-List | Out-Host
if ($failed -gt 0) { throw "$failed image(s) failed. See ERROR rows above." }
